module.exports = {
  components: {
    // FinancialBot
    'BalanceRetrieval': require('./banking/balance_retrieval'),
  }
};
